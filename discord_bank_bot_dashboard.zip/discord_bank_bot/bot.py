import os
import sqlite3
import time
import secrets
import logging
from decimal import Decimal, InvalidOperation, ROUND_DOWN
from datetime import datetime, timezone, timedelta

import discord
from discord import app_commands
from discord.ext import commands
from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError, VerificationError, InvalidHash

DB_PATH = os.getenv("BANK_DB_PATH", "bank.db")
TOKEN = os.getenv("DISCORD_TOKEN")
ADMIN_IDS = {int(x.strip()) for x in os.getenv("BANK_ADMIN_IDS", "").split(",") if x.strip().isdigit()}

CURRENCY = os.getenv("BANK_CURRENCY", "₱")
SESSION_MINUTES = int(os.getenv("SESSION_MINUTES", "30"))
MAX_LOGIN_ATTEMPTS = int(os.getenv("MAX_LOGIN_ATTEMPTS", "5"))
LOCKOUT_MINUTES = int(os.getenv("LOCKOUT_MINUTES", "15"))

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("discord-bank")
ph = PasswordHasher()

def now_iso():
    return datetime.now(timezone.utc).isoformat()

def money(value):
    try:
        d = Decimal(str(value)).quantize(Decimal("0.01"), rounding=ROUND_DOWN)
        if d < 0:
            raise ValueError
        return d
    except (InvalidOperation, ValueError):
        raise ValueError("Invalid amount")

def fmt_money(value):
    return f"{CURRENCY}{Decimal(str(value)):,.2f}"

def db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    con.execute("PRAGMA journal_mode=WAL")
    return con

def init_db():
    con = db()
    con.executescript("""
    CREATE TABLE IF NOT EXISTS accounts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        discord_id INTEGER NOT NULL UNIQUE,
        discord_username TEXT,
        username TEXT NOT NULL UNIQUE COLLATE NOCASE,
        password_hash TEXT NOT NULL,
        balance_cents INTEGER NOT NULL DEFAULT 0 CHECK(balance_cents >= 0),
        created_at TEXT NOT NULL,
        last_login_at TEXT,
        failed_logins INTEGER NOT NULL DEFAULT 0,
        locked_until TEXT
    );

    CREATE TABLE IF NOT EXISTS transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        account_id INTEGER,
        type TEXT NOT NULL,
        amount_cents INTEGER NOT NULL,
        balance_after_cents INTEGER,
        related_account_id INTEGER,
        reference TEXT,
        note TEXT,
        created_at TEXT NOT NULL,
        FOREIGN KEY(account_id) REFERENCES accounts(id),
        FOREIGN KEY(related_account_id) REFERENCES accounts(id)
    );

    CREATE TABLE IF NOT EXISTS requests (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        account_id INTEGER NOT NULL,
        type TEXT NOT NULL CHECK(type IN ('deposit','withdraw')),
        amount_cents INTEGER NOT NULL CHECK(amount_cents > 0),
        status TEXT NOT NULL DEFAULT 'pending',
        created_at TEXT NOT NULL,
        reviewed_at TEXT,
        reviewed_by INTEGER,
        note TEXT,
        FOREIGN KEY(account_id) REFERENCES accounts(id)
    );

    CREATE TABLE IF NOT EXISTS audit_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        actor_discord_id INTEGER NOT NULL,
        action TEXT NOT NULL,
        target_account_id INTEGER,
        details TEXT,
        created_at TEXT NOT NULL,
        FOREIGN KEY(target_account_id) REFERENCES accounts(id)
    );

    CREATE TABLE IF NOT EXISTS admin_roles (
        guild_id INTEGER NOT NULL,
        role_id INTEGER NOT NULL,
        created_at TEXT NOT NULL,
        created_by INTEGER NOT NULL,
        PRIMARY KEY(guild_id, role_id)
    );

    CREATE INDEX IF NOT EXISTS idx_transactions_account ON transactions(account_id, id DESC);
    CREATE INDEX IF NOT EXISTS idx_requests_status ON requests(status, id DESC);
    """)
    # Backward-compatible migration for databases created by older versions.
    cols = {r[1] for r in con.execute("PRAGMA table_info(accounts)").fetchall()}
    if "discord_username" not in cols:
        con.execute("ALTER TABLE accounts ADD COLUMN discord_username TEXT")
    con.commit()
    con.close()

sessions = {}  # discord_id -> {"account_id": int, "expires": float}
login_attempts = {}  # discord_id -> {"count": int, "until": float}

def account_by_discord(discord_id):
    con = db()
    row = con.execute("SELECT * FROM accounts WHERE discord_id=?", (discord_id,)).fetchone()
    con.close()
    return row

def sync_discord_identity(user):
    """Keep the visible Discord username attached to the bank account current.
    Security still uses immutable Discord user ID, not the mutable username.
    """
    con = db()
    con.execute("UPDATE accounts SET discord_username=? WHERE discord_id=?", (str(user), user.id))
    con.commit()
    con.close()

def account_by_username(username):
    con = db()
    row = con.execute("SELECT * FROM accounts WHERE username=? COLLATE NOCASE", (username,)).fetchone()
    con.close()
    return row

def account_by_discord_name(name):
    """Find an account by the stored Discord username/tag (display-only lookup)."""
    name = str(name).strip().lstrip("@")
    con = db()
    row = con.execute(
        "SELECT * FROM accounts WHERE discord_username=? COLLATE NOCASE", (name,)
    ).fetchone()
    con.close()
    return row

def audit(actor_id, action, target_id=None, details=""):
    con = db()
    con.execute(
        "INSERT INTO audit_log(actor_discord_id, action, target_account_id, details, created_at) VALUES(?,?,?,?,?)",
        (actor_id, action, target_id, details, now_iso())
    )
    con.commit()
    con.close()

def is_authenticated(discord_id):
    s = sessions.get(discord_id)
    if not s:
        return None
    if s["expires"] < time.time():
        sessions.pop(discord_id, None)
        return None
    s["expires"] = time.time() + SESSION_MINUTES * 60
    acc = account_by_discord(discord_id)
    if acc:
        # Discord usernames can change; refresh the stored display name.
        # The account remains bound to discord_id.
        con = db()
        con.execute("UPDATE accounts SET discord_username=? WHERE discord_id=?", (str(acc["discord_username"] or discord_id), discord_id))
        con.commit(); con.close()
    return acc

async def require_admin(interaction):
    if interaction.user.id in ADMIN_IDS:
        return True
    if interaction.guild is None:
        return False
    member = interaction.user if isinstance(interaction.user, discord.Member) else interaction.guild.get_member(interaction.user.id)
    if not member:
        return False
    con = db()
    rows = con.execute("SELECT role_id FROM admin_roles WHERE guild_id=?", (interaction.guild.id,)).fetchall()
    con.close()
    allowed = {r["role_id"] for r in rows}
    return any(role.id in allowed for role in member.roles)

def get_admin_roles(guild_id):
    con=db(); rows=con.execute("SELECT role_id FROM admin_roles WHERE guild_id=? ORDER BY role_id", (guild_id,)).fetchall(); con.close()
    return [r["role_id"] for r in rows]

class LoginModal(discord.ui.Modal, title="Bank Login"):
    username = discord.ui.TextInput(label="Bank username", max_length=32)
    password = discord.ui.TextInput(label="Password", style=discord.TextStyle.short, min_length=8, max_length=128)

    async def on_submit(self, interaction: discord.Interaction):
        uid = interaction.user.id
        sync_discord_identity(interaction.user)
        state = login_attempts.get(uid, {"count": 0, "until": 0})
        if state["until"] > time.time():
            await interaction.response.send_message(
                f"Too many failed attempts. Try again in {int(state['until']-time.time())} seconds.",
                ephemeral=True
            )
            return

        acc = account_by_username(str(self.username.value).strip())
        if not acc or acc["discord_id"] != uid:
            state["count"] += 1
            if state["count"] >= MAX_LOGIN_ATTEMPTS:
                state = {"count": 0, "until": time.time() + LOCKOUT_MINUTES * 60}
            login_attempts[uid] = state
            await interaction.response.send_message("Invalid login.", ephemeral=True)
            return

        try:
            ph.verify(acc["password_hash"], str(self.password.value))
        except (VerifyMismatchError, VerificationError, InvalidHash):
            state["count"] += 1
            if state["count"] >= MAX_LOGIN_ATTEMPTS:
                state = {"count": 0, "until": time.time() + LOCKOUT_MINUTES * 60}
            login_attempts[uid] = state
            await interaction.response.send_message("Invalid login.", ephemeral=True)
            return

        con = db()
        con.execute("UPDATE accounts SET last_login_at=?, failed_logins=0, locked_until=NULL WHERE id=?", (now_iso(), acc["id"]))
        con.commit()
        con.close()
        login_attempts.pop(uid, None)
        sessions[uid] = {"account_id": acc["id"], "expires": time.time() + SESSION_MINUTES * 60}
        audit(uid, "login", acc["id"])
        await interaction.response.send_message(
            f"✅ Logged in as **{acc['username']}**. Session expires after {SESSION_MINUTES} minutes of inactivity.",
            ephemeral=True
        )

class RegisterModal(discord.ui.Modal, title="Create Bank Account"):
    username = discord.ui.TextInput(label="Bank username", min_length=3, max_length=32)
    password = discord.ui.TextInput(label="Password", style=discord.TextStyle.short, min_length=8, max_length=128)
    confirm = discord.ui.TextInput(label="Confirm password", style=discord.TextStyle.short, min_length=8, max_length=128)

    async def on_submit(self, interaction: discord.Interaction):
        uid = interaction.user.id
        if account_by_discord(uid):
            await interaction.response.send_message("You already have a bank account.", ephemeral=True)
            return
        u = str(self.username.value).strip()
        if self.password.value != self.confirm.value:
            await interaction.response.send_message("Passwords do not match.", ephemeral=True)
            return
        if any(c.isspace() for c in u):
            await interaction.response.send_message("Username cannot contain spaces.", ephemeral=True)
            return
        if account_by_username(u):
            await interaction.response.send_message("That username is already taken.", ephemeral=True)
            return

        password_hash = ph.hash(str(self.password.value))
        con = db()
        cur = con.execute(
            "INSERT INTO accounts(discord_id, discord_username, username, password_hash, created_at) VALUES(?,?,?,?,?)",
            (uid, str(interaction.user), u, password_hash, now_iso())
        )
        acc_id = cur.lastrowid
        con.commit()
        con.close()
        audit(uid, "register", acc_id)
        await interaction.response.send_message(
            f"✅ Account **{u}** created and permanently linked to your Discord account.\n"
            f"Starting balance: {fmt_money('0.00')}\n"
            f"Use `/login` to authenticate.",
            ephemeral=True
        )

class Bank(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="register", description="Create your bank account")
    async def register(self, interaction: discord.Interaction):
        await interaction.response.send_modal(RegisterModal())

    @app_commands.command(name="login", description="Log in to your bank account")
    async def login(self, interaction: discord.Interaction):
        await interaction.response.send_modal(LoginModal())

    @app_commands.command(name="logout", description="Log out of your bank session")
    async def logout(self, interaction: discord.Interaction):
        sessions.pop(interaction.user.id, None)
        await interaction.response.send_message("Logged out.", ephemeral=True)

    @app_commands.command(name="balance", description="View your bank balance")
    async def balance(self, interaction: discord.Interaction):
        sync_discord_identity(interaction.user)
        acc = is_authenticated(interaction.user.id)
        if not acc:
            await interaction.response.send_message("Please `/login` first.", ephemeral=True)
            return
        await interaction.response.send_message(
            f"🏦 **{acc['username']}**\nBalance: **{fmt_money(acc['balance_cents']/100)}**",
            ephemeral=True
        )

    @app_commands.command(name="deposit", description="Submit a deposit request for admin approval")
    @app_commands.describe(amount="Amount to deposit")
    async def deposit(self, interaction: discord.Interaction, amount: str):
        acc = is_authenticated(interaction.user.id)
        if not acc:
            await interaction.response.send_message("Please `/login` first.", ephemeral=True); return
        try:
            cents = int(money(amount) * 100)
            if cents <= 0: raise ValueError
        except ValueError:
            await interaction.response.send_message("Enter a positive amount, e.g. `1000.00`.", ephemeral=True); return
        con = db()
        cur = con.execute(
            "INSERT INTO requests(account_id,type,amount_cents,created_at) VALUES(?,?,?,?)",
            (acc["id"], "deposit", cents, now_iso())
        )
        rid = cur.lastrowid
        con.commit(); con.close()
        audit(interaction.user.id, "deposit_request", acc["id"], f"request={rid};amount_cents={cents}")
        await interaction.response.send_message(
            f"📥 Deposit request **#{rid}** submitted for **{fmt_money(cents/100)}**.\n"
            "An administrator must approve it before your balance changes.",
            ephemeral=True
        )

    @app_commands.command(name="withdraw", description="Submit a withdrawal request for admin approval")
    @app_commands.describe(amount="Amount to withdraw")
    async def withdraw(self, interaction: discord.Interaction, amount: str):
        acc = is_authenticated(interaction.user.id)
        if not acc:
            await interaction.response.send_message("Please `/login` first.", ephemeral=True); return
        try:
            cents = int(money(amount) * 100)
            if cents <= 0: raise ValueError
        except ValueError:
            await interaction.response.send_message("Enter a positive amount, e.g. `250.00`.", ephemeral=True); return
        if cents > acc["balance_cents"]:
            await interaction.response.send_message("Insufficient balance.", ephemeral=True); return
        con = db()
        cur = con.execute(
            "INSERT INTO requests(account_id,type,amount_cents,created_at) VALUES(?,?,?,?)",
            (acc["id"], "withdraw", cents, now_iso())
        )
        rid = cur.lastrowid
        con.commit(); con.close()
        audit(interaction.user.id, "withdraw_request", acc["id"], f"request={rid};amount_cents={cents}")
        await interaction.response.send_message(
            f"📤 Withdrawal request **#{rid}** submitted for **{fmt_money(cents/100)}**.\n"
            "An administrator must approve it before your balance changes.",
            ephemeral=True
        )

    @app_commands.command(name="transfer", description="Transfer funds to another registered bank user")
    @app_commands.describe(username="Recipient bank username", amount="Amount to transfer")
    async def transfer(self, interaction: discord.Interaction, username: str, amount: str):
        sender = is_authenticated(interaction.user.id)
        if not sender:
            await interaction.response.send_message("Please `/login` first.", ephemeral=True); return
        receiver = account_by_username(username.strip())
        if not receiver:
            await interaction.response.send_message("Recipient account not found.", ephemeral=True); return
        if receiver["id"] == sender["id"]:
            await interaction.response.send_message("You cannot transfer to yourself.", ephemeral=True); return
        try:
            cents = int(money(amount) * 100)
            if cents <= 0: raise ValueError
        except ValueError:
            await interaction.response.send_message("Enter a positive amount.", ephemeral=True); return

        con = db()
        try:
            con.execute("BEGIN IMMEDIATE")
            s = con.execute("SELECT * FROM accounts WHERE id=?", (sender["id"],)).fetchone()
            if s["balance_cents"] < cents:
                con.rollback()
                await interaction.response.send_message("Insufficient balance.", ephemeral=True); return
            new_sender = s["balance_cents"] - cents
            r = con.execute("SELECT * FROM accounts WHERE id=?", (receiver["id"],)).fetchone()
            new_receiver = r["balance_cents"] + cents
            con.execute("UPDATE accounts SET balance_cents=? WHERE id=?", (new_sender, sender["id"]))
            con.execute("UPDATE accounts SET balance_cents=? WHERE id=?", (new_receiver, receiver["id"]))
            ref = secrets.token_hex(8)
            con.execute(
                "INSERT INTO transactions(account_id,type,amount_cents,balance_after_cents,related_account_id,reference,note,created_at) VALUES(?,?,?,?,?,?,?,?)",
                (sender["id"], "transfer_out", -cents, new_sender, receiver["id"], ref, f"To {receiver['username']}", now_iso())
            )
            con.execute(
                "INSERT INTO transactions(account_id,type,amount_cents,balance_after_cents,related_account_id,reference,note,created_at) VALUES(?,?,?,?,?,?,?,?)",
                (receiver["id"], "transfer_in", cents, new_receiver, sender["id"], ref, f"From {sender['username']}", now_iso())
            )
            con.commit()
        except Exception:
            con.rollback()
            raise
        finally:
            con.close()
        audit(interaction.user.id, "transfer", sender["id"], f"to={receiver['id']};amount_cents={cents};ref={ref}")
        await interaction.response.send_message(
            f"✅ Transfer complete: **{fmt_money(cents/100)}** sent to **{receiver['username']}**.\n"
            f"New balance: **{fmt_money(new_sender/100)}**",
            ephemeral=True
        )

    @app_commands.command(name="transactions", description="View your recent transaction history")
    @app_commands.describe(limit="Number of transactions, 1-20")
    async def transactions(self, interaction: discord.Interaction, limit: int = 10):
        acc = is_authenticated(interaction.user.id)
        if not acc:
            await interaction.response.send_message("Please `/login` first.", ephemeral=True); return
        limit = max(1, min(limit, 20))
        con = db()
        rows = con.execute(
            "SELECT * FROM transactions WHERE account_id=? ORDER BY id DESC LIMIT ?",
            (acc["id"], limit)
        ).fetchall()
        con.close()
        if not rows:
            await interaction.response.send_message("No transactions yet.", ephemeral=True); return
        lines = []
        for r in rows:
            sign = "+" if r["amount_cents"] >= 0 else ""
            lines.append(f"`#{r['id']}` {r['type']} {sign}{fmt_money(r['amount_cents']/100)} — balance {fmt_money(r['balance_after_cents']/100)}")
        await interaction.response.send_message("\n".join(lines), ephemeral=True)

class Admin(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def check(self, interaction):
        if not await require_admin(interaction):
            await interaction.response.send_message("Administrator only.", ephemeral=True)
            return False
        return True

    @app_commands.command(name="admin_roles", description="List configured admin roles for this server")
    async def admin_roles(self, interaction: discord.Interaction):
        if not await self.check(interaction): return
        if not interaction.guild:
            await interaction.response.send_message("This command can only be used in a server.", ephemeral=True); return
        ids = get_admin_roles(interaction.guild.id)
        if not ids:
            await interaction.response.send_message("No server admin roles are configured. Use the dashboard to add one.", ephemeral=True); return
        names=[]
        for rid in ids:
            role=interaction.guild.get_role(rid)
            names.append(f"{role.mention if role else '`'+str(rid)+'`'}")
        await interaction.response.send_message("🛡️ Admin roles: " + ", ".join(names), ephemeral=True)

    @app_commands.command(name="dashboard", description="Open the bank administration dashboard")
    async def dashboard(self, interaction: discord.Interaction):
        url = os.getenv("DASHBOARD_URL", "").strip()
        if not url:
            await interaction.response.send_message("Dashboard is not configured. Set DASHBOARD_URL in the environment.", ephemeral=True)
            return
        await interaction.response.send_message(f"🖥️ **Bank Dashboard**\n{url}", ephemeral=True)

    @app_commands.command(name="admin_pending", description="List pending deposit/withdrawal requests")
    async def pending(self, interaction: discord.Interaction):
        if not await self.check(interaction): return
        con = db()
        rows = con.execute("""
            SELECT r.*, a.username, a.discord_id, a.balance_cents
            FROM requests r JOIN accounts a ON a.id=r.account_id
            WHERE r.status='pending' ORDER BY r.id ASC LIMIT 50
        """).fetchall()
        con.close()
        if not rows:
            await interaction.response.send_message("No pending requests.", ephemeral=True); return
        lines = [
            f"#{r['id']} {r['type']} {fmt_money(r['amount_cents']/100)} | {r['username']} | balance {fmt_money(r['balance_cents']/100)}"
            for r in rows
        ]
        await interaction.response.send_message("\n".join(lines), ephemeral=True)

    @app_commands.command(name="admin_approve", description="Approve a pending deposit/withdrawal request")
    @app_commands.describe(request_id="Request ID")
    async def approve(self, interaction: discord.Interaction, request_id: int):
        if not await self.check(interaction): return
        con = db()
        try:
            con.execute("BEGIN IMMEDIATE")
            req = con.execute("SELECT * FROM requests WHERE id=? AND status='pending'", (request_id,)).fetchone()
            if not req:
                con.rollback()
                await interaction.response.send_message("Pending request not found.", ephemeral=True); return
            acc = con.execute("SELECT * FROM accounts WHERE id=?", (req["account_id"],)).fetchone()
            amount = req["amount_cents"]
            if req["type"] == "withdraw":
                if acc["balance_cents"] < amount:
                    con.rollback()
                    await interaction.response.send_message("Cannot approve: insufficient current balance.", ephemeral=True); return
                delta = -amount
                tx_type = "withdraw"
            else:
                delta = amount
                tx_type = "deposit"
            new_bal = acc["balance_cents"] + delta
            con.execute("UPDATE accounts SET balance_cents=? WHERE id=?", (new_bal, acc["id"]))
            con.execute("""
                INSERT INTO transactions(account_id,type,amount_cents,balance_after_cents,reference,note,created_at)
                VALUES(?,?,?,?,?,?,?)
            """, (acc["id"], tx_type, delta, new_bal, f"request-{request_id}", "Admin approved request", now_iso()))
            con.execute(
                "UPDATE requests SET status='approved', reviewed_at=?, reviewed_by=? WHERE id=?",
                (now_iso(), interaction.user.id, request_id)
            )
            con.commit()
        except Exception:
            con.rollback()
            raise
        finally:
            con.close()
        audit(interaction.user.id, "approve_request", req["account_id"], f"request={request_id}")
        await interaction.response.send_message(
            f"✅ Request #{request_id} approved. {req['type'].title()} {fmt_money(amount/100)} for **{acc['username']}**.\n"
            f"New balance: **{fmt_money(new_bal/100)}**",
            ephemeral=True
        )

    @app_commands.command(name="admin_deny", description="Deny a pending request")
    @app_commands.describe(request_id="Request ID", reason="Optional reason")
    async def deny(self, interaction: discord.Interaction, request_id: int, reason: str = "No reason provided"):
        if not await self.check(interaction): return
        con = db()
        req = con.execute("SELECT * FROM requests WHERE id=? AND status='pending'", (request_id,)).fetchone()
        if not req:
            con.close()
            await interaction.response.send_message("Pending request not found.", ephemeral=True); return
        con.execute(
            "UPDATE requests SET status='denied', reviewed_at=?, reviewed_by=?, note=? WHERE id=?",
            (now_iso(), interaction.user.id, reason[:500], request_id)
        )
        con.commit(); con.close()
        audit(interaction.user.id, "deny_request", req["account_id"], f"request={request_id};reason={reason[:200]}")
        await interaction.response.send_message(f"❌ Request #{request_id} denied.", ephemeral=True)

    @app_commands.command(name="admin_credit", description="Directly credit a user's account")
    @app_commands.describe(username="Bank username", amount="Amount", note="Reason")
    async def credit(self, interaction: discord.Interaction, username: str, amount: str, note: str = "Admin credit"):
        if not await self.check(interaction): return
        acc = account_by_username(username.strip())
        if not acc:
            await interaction.response.send_message("Account not found.", ephemeral=True); return
        try: cents = int(money(amount) * 100)
        except ValueError:
            await interaction.response.send_message("Invalid amount.", ephemeral=True); return
        con = db()
        con.execute("BEGIN IMMEDIATE")
        row = con.execute("SELECT * FROM accounts WHERE id=?", (acc["id"],)).fetchone()
        new_bal = row["balance_cents"] + cents
        con.execute("UPDATE accounts SET balance_cents=? WHERE id=?", (new_bal, acc["id"]))
        con.execute("INSERT INTO transactions(account_id,type,amount_cents,balance_after_cents,note,created_at) VALUES(?,?,?,?,?,?)",
                    (acc["id"], "admin_credit", cents, new_bal, note[:500], now_iso()))
        con.commit(); con.close()
        audit(interaction.user.id, "admin_credit", acc["id"], f"amount_cents={cents};note={note[:200]}")
        await interaction.response.send_message(f"✅ Credited {fmt_money(cents/100)} to {acc['username']}. New balance: {fmt_money(new_bal/100)}", ephemeral=True)

    @app_commands.command(name="admin_debit", description="Directly debit a user's account")
    @app_commands.describe(username="Bank username", amount="Amount", note="Reason")
    async def debit(self, interaction: discord.Interaction, username: str, amount: str, note: str = "Admin debit"):
        if not await self.check(interaction): return
        acc = account_by_username(username.strip())
        if not acc:
            await interaction.response.send_message("Account not found.", ephemeral=True); return
        try: cents = int(money(amount) * 100)
        except ValueError:
            await interaction.response.send_message("Invalid amount.", ephemeral=True); return
        con = db()
        con.execute("BEGIN IMMEDIATE")
        row = con.execute("SELECT * FROM accounts WHERE id=?", (acc["id"],)).fetchone()
        if row["balance_cents"] < cents:
            con.rollback(); con.close()
            await interaction.response.send_message("Insufficient balance.", ephemeral=True); return
        new_bal = row["balance_cents"] - cents
        con.execute("UPDATE accounts SET balance_cents=? WHERE id=?", (new_bal, acc["id"]))
        con.execute("INSERT INTO transactions(account_id,type,amount_cents,balance_after_cents,note,created_at) VALUES(?,?,?,?,?,?)",
                    (acc["id"], "admin_debit", -cents, new_bal, note[:500], now_iso()))
        con.commit(); con.close()
        audit(interaction.user.id, "admin_debit", acc["id"], f"amount_cents={cents};note={note[:200]}")
        await interaction.response.send_message(f"✅ Debited {fmt_money(cents/100)} from {acc['username']}. New balance: {fmt_money(new_bal/100)}", ephemeral=True)

    @app_commands.command(name="admin_add_funds", description="ADMIN ONLY: generate virtual funds for a user")
    @app_commands.describe(username="Bank username", amount="Amount of virtual funds to add", note="Reason for the adjustment")
    async def admin_add_funds(self, interaction: discord.Interaction, username: str, amount: str, note: str = "Admin generated funds"):
        if not await self.check(interaction): return
        acc = account_by_username(username.strip())
        if not acc:
            await interaction.response.send_message("Account not found.", ephemeral=True); return
        try:
            cents = int(money(amount) * 100)
            if cents <= 0: raise ValueError
        except ValueError:
            await interaction.response.send_message("Enter a positive amount, e.g. `1000.00`.", ephemeral=True); return
        con = db()
        try:
            con.execute("BEGIN IMMEDIATE")
            row = con.execute("SELECT * FROM accounts WHERE id=?", (acc["id"],)).fetchone()
            new_bal = row["balance_cents"] + cents
            con.execute("UPDATE accounts SET balance_cents=? WHERE id=?", (new_bal, acc["id"]))
            con.execute("INSERT INTO transactions(account_id,type,amount_cents,balance_after_cents,note,created_at) VALUES(?,?,?,?,?,?)", (acc["id"], "admin_add_funds", cents, new_bal, note[:500], now_iso()))
            con.commit()
        except Exception:
            con.rollback(); raise
        finally:
            con.close()
        audit(interaction.user.id, "admin_add_funds", acc["id"], f"amount_cents={cents};note={note[:200]}")
        await interaction.response.send_message(f"✅ **Funds generated by admin.**\nAccount: **{acc['username']}**\nAdded: **{fmt_money(cents/100)}**\nNew balance: **{fmt_money(new_bal/100)}**", ephemeral=True)

    @app_commands.command(name="admin_remove_funds", description="ADMIN ONLY: remove virtual funds from a user")
    @app_commands.describe(username="Bank username", amount="Amount of virtual funds to remove", note="Reason for the adjustment")
    async def admin_remove_funds(self, interaction: discord.Interaction, username: str, amount: str, note: str = "Admin removed funds"):
        if not await self.check(interaction): return
        acc = account_by_username(username.strip())
        if not acc:
            await interaction.response.send_message("Account not found.", ephemeral=True); return
        try:
            cents = int(money(amount) * 100)
            if cents <= 0: raise ValueError
        except ValueError:
            await interaction.response.send_message("Enter a positive amount, e.g. `250.00`.", ephemeral=True); return
        con = db()
        try:
            con.execute("BEGIN IMMEDIATE")
            row = con.execute("SELECT * FROM accounts WHERE id=?", (acc["id"],)).fetchone()
            if row["balance_cents"] < cents:
                con.rollback()
                await interaction.response.send_message(f"Cannot remove {fmt_money(cents/100)}. Current balance is only {fmt_money(row['balance_cents']/100)}.", ephemeral=True)
                return
            new_bal = row["balance_cents"] - cents
            con.execute("UPDATE accounts SET balance_cents=? WHERE id=?", (new_bal, acc["id"]))
            con.execute("INSERT INTO transactions(account_id,type,amount_cents,balance_after_cents,note,created_at) VALUES(?,?,?,?,?,?)", (acc["id"], "admin_remove_funds", -cents, new_bal, note[:500], now_iso()))
            con.commit()
        except Exception:
            con.rollback(); raise
        finally:
            con.close()
        audit(interaction.user.id, "admin_remove_funds", acc["id"], f"amount_cents={cents};note={note[:200]}")
        await interaction.response.send_message(f"✅ **Funds removed by admin.**\nAccount: **{acc['username']}**\nRemoved: **{fmt_money(cents/100)}**\nNew balance: **{fmt_money(new_bal/100)}**", ephemeral=True)

    @app_commands.command(name="admin_discord_user", description="ADMIN ONLY: find a bank account by Discord username")
    @app_commands.describe(discord_username="Discord username/tag, for example Yoriichi or Yoriichi#1234")
    async def admin_discord_user(self, interaction: discord.Interaction, discord_username: str):
        if not await self.check(interaction): return
        acc = account_by_discord_name(discord_username)
        if not acc:
            await interaction.response.send_message("No bank account is linked to that Discord username.", ephemeral=True)
            return
        await interaction.response.send_message(
            f"**Bank account:** {acc['username']}\n"
            f"**Discord username:** {acc['discord_username'] or 'Unknown'}\n"
            f"**Discord ID:** `{acc['discord_id']}`\n"
            f"**Balance:** **{fmt_money(acc['balance_cents']/100)}**",
            ephemeral=True
        )

    @app_commands.command(name="admin_user", description="View a bank account")
    @app_commands.describe(username="Bank username")
    async def user(self, interaction: discord.Interaction, username: str):
        if not await self.check(interaction): return
        acc = account_by_username(username.strip())
        if not acc:
            await interaction.response.send_message("Account not found.", ephemeral=True); return
        await interaction.response.send_message(
            f"**{acc['username']}**\nDiscord username: **{acc['discord_username'] or 'Unknown'}**\nDiscord ID: `{acc['discord_id']}`\n"
            f"Balance: **{fmt_money(acc['balance_cents']/100)}**\nCreated: {acc['created_at']}\nLast login: {acc['last_login_at'] or 'Never'}",
            ephemeral=True
        )

    @app_commands.command(name="admin_list", description="List registered bank accounts")
    async def list_accounts(self, interaction: discord.Interaction):
        if not await self.check(interaction): return
        con = db()
        rows = con.execute("SELECT username,balance_cents,created_at FROM accounts ORDER BY username COLLATE NOCASE").fetchall()
        con.close()
        if not rows:
            await interaction.response.send_message("No accounts.", ephemeral=True); return
        lines = [f"**{r['username']}** — {fmt_money(r['balance_cents']/100)} — {r['created_at']}" for r in rows[:50]]
        await interaction.response.send_message("\n".join(lines), ephemeral=True)

intents = discord.Intents.default()
bot = commands.Bot(command_prefix="!", intents=intents)

@bot.event
async def on_ready():
    log.info("Logged in as %s", bot.user)
    try:
        synced = await bot.tree.sync()
        log.info("Synced %d application commands", len(synced))
    except Exception:
        log.exception("Command sync failed")

async def main():
    if not TOKEN:
        raise RuntimeError("Set DISCORD_TOKEN in your environment.")
    if not ADMIN_IDS:
        log.warning("BANK_ADMIN_IDS is empty. No admin commands will work.")
    init_db()
    await bot.add_cog(Bank(bot))
    await bot.add_cog(Admin(bot))
    await bot.start(TOKEN)

if __name__ == "__main__":
    import asyncio
    asyncio.run(main())
