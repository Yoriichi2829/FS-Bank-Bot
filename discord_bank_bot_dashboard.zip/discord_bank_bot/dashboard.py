import os
import sqlite3
from urllib.parse import urlencode
from flask import Flask, session, redirect, request, render_template_string, abort
import requests

DB_PATH = os.getenv("BANK_DB_PATH", "bank.db")
DISCORD_CLIENT_ID = os.getenv("DISCORD_CLIENT_ID", "")
DISCORD_CLIENT_SECRET = os.getenv("DISCORD_CLIENT_SECRET", "")
DISCORD_REDIRECT_URI = os.getenv("DISCORD_REDIRECT_URI", "")
DASHBOARD_URL = os.getenv("DASHBOARD_URL", "http://localhost:8080")
DISCORD_TOKEN = os.getenv("DISCORD_TOKEN", "")
BOT_INVITE_URL = os.getenv("BOT_INVITE_URL", "")
ADMIN_IDS = {int(x.strip()) for x in os.getenv("BANK_ADMIN_IDS", "").split(",") if x.strip().isdigit()}

app = Flask(__name__)
app.secret_key = os.getenv("DASHBOARD_SECRET", "change-this-secret")
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
app.config["SESSION_COOKIE_SECURE"] = os.getenv("DASHBOARD_HTTPS", "0") == "1"


def db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con


def init_db():
    con=db()
    con.execute("""CREATE TABLE IF NOT EXISTS admin_roles (
        guild_id INTEGER NOT NULL,
        role_id INTEGER NOT NULL,
        created_at TEXT NOT NULL,
        created_by INTEGER NOT NULL,
        PRIMARY KEY(guild_id, role_id)
    )""")
    con.commit(); con.close()


def discord_api(path, method="GET", data=None):
    headers={"Authorization": f"Bearer {session.get('access_token')}"}
    r=requests.request(method, "https://discord.com/api/v10"+path, headers=headers, data=data, timeout=15)
    if not r.ok:
        abort(r.status_code, r.text[:300])
    return r.json()


def current_user():
    return session.get("user")


def is_global_admin():
    u=current_user(); return bool(u and int(u["id"]) in ADMIN_IDS)


def guilds_for_user():
    return discord_api("/users/@me/guilds")


def bot_guild_ids():
    # Bot token is used only server-side; never exposed to browser.
    r=requests.get("https://discord.com/api/v10/users/@me/guilds", headers={"Authorization": f"Bot {DISCORD_TOKEN}"}, timeout=15)
    return {int(g["id"]) for g in r.json()} if r.ok else set()


def can_manage_guild(guild):
    if is_global_admin(): return True
    # Discord guild permissions bit 5 = MANAGE_GUILD (0x20); owner is also allowed.
    return bool(guild.get("owner", False) or (int(guild.get("permissions", 0)) & 0x20))


def require_login():
    if not current_user(): return redirect("/login")
    return None

STYLE='''<style>body{font-family:system-ui;margin:0;background:#0f172a;color:#e5e7eb}.wrap{max-width:1100px;margin:auto;padding:24px}a,button{color:inherit}a.btn,button{background:#2563eb;border:0;padding:10px 14px;border-radius:8px;text-decoration:none;cursor:pointer}.card{background:#1e293b;padding:18px;border-radius:12px;margin:12px 0}.muted{color:#94a3b8}.role{display:flex;justify-content:space-between;align-items:center;padding:10px;background:#334155;border-radius:8px;margin:6px 0}select,input{padding:10px;border-radius:8px;border:1px solid #475569;background:#0f172a;color:white}.danger{background:#dc2626!important}</style>'''

@app.route("/")
def home():
    if not current_user():
        return render_template_string(STYLE+'''<div class="wrap"><div class="card"><h1>🏦 Discord Bank Dashboard</h1><p class="muted">Manage your bot's server admin roles and configuration.</p><a class="btn" href="/login">Login with Discord</a><a class="btn" href="/invite">Add Bot to Discord</a></div></div>''')
    guilds=guilds_for_user(); bots=bot_guild_ids()
    manageable=[g for g in guilds if can_manage_guild(g) and int(g["id"]) in bots]
    return render_template_string(STYLE+'''<div class="wrap"><h1>🏦 Bank Dashboard</h1><p>Signed in as <b>{{user.username}}</b>.</p><a class="btn" href="/invite">Add Bot to a Server</a> <a class="btn" href="/logout">Logout</a><div class="card"><h2>Manage servers</h2>{% if gs %}{% for g in gs %}<p><a class="btn" href="/guild/{{g.id}}">{{g.name}}</a></p>{% endfor %}{% else %}<p class="muted">No manageable servers where the bot is installed.</p>{% endif %}</div></div>''', user=current_user(), gs=manageable)

@app.route("/login")
def login():
    if not DISCORD_CLIENT_ID or not DISCORD_CLIENT_SECRET or not DISCORD_REDIRECT_URI:
        return "Set DISCORD_CLIENT_ID, DISCORD_CLIENT_SECRET and DISCORD_REDIRECT_URI first.", 500
    state=os.urandom(24).hex(); session["oauth_state"]=state
    q=urlencode({"client_id":DISCORD_CLIENT_ID,"redirect_uri":DISCORD_REDIRECT_URI,"response_type":"code","scope":"identify guilds"})
    return redirect("https://discord.com/oauth2/authorize?"+q)

@app.route("/callback")
def callback():
    if request.args.get("state") != session.pop("oauth_state", None): return "Invalid OAuth state", 400
    code=request.args.get("code")
    if not code: return "Missing code",400
    token=requests.post("https://discord.com/api/v10/oauth2/token", data={"client_id":DISCORD_CLIENT_ID,"client_secret":DISCORD_CLIENT_SECRET,"grant_type":"authorization_code","code":code,"redirect_uri":DISCORD_REDIRECT_URI}, timeout=15)
    if not token.ok: return "Discord OAuth failed",400
    session["access_token"]=token.json()["access_token"]
    session["user"]=discord_api("/users/@me")
    return redirect("/")

@app.route("/logout")
def logout():
    session.clear(); return redirect("/")

@app.route("/invite")
def invite():
    if BOT_INVITE_URL:
        return redirect(BOT_INVITE_URL)
    if not DISCORD_CLIENT_ID: return "Set DISCORD_CLIENT_ID first.",500
    # permissions: View Channel, Send Messages, Embed Links, Use Application Commands
    perms=2147485760
    q=urlencode({"client_id":DISCORD_CLIENT_ID,"permissions":perms,"scope":"bot applications.commands"})
    return redirect("https://discord.com/oauth2/authorize?"+q)

@app.route("/guild/<int:guild_id>")
def guild_page(guild_id):
    r=require_login()
    if r: return r
    guild=next((g for g in guilds_for_user() if int(g["id"])==guild_id),None)
    if not guild or not can_manage_guild(guild): abort(403)
    if guild_id not in bot_guild_ids(): abort(400, "Bot is not installed in this server. Use Add Bot to a Server first.")
    # Bot endpoint fetches roles; requires bot in guild.
    rr=requests.get(f"https://discord.com/api/v10/guilds/{guild_id}/roles", headers={"Authorization":f"Bot {DISCORD_TOKEN}"}, timeout=15)
    if not rr.ok: abort(rr.status_code, "Unable to read server roles")
    roles=[x for x in rr.json() if not x.get("managed")]
    con=db(); configured={r["role_id"] for r in con.execute("SELECT role_id FROM admin_roles WHERE guild_id=?",(guild_id,)).fetchall()}; con.close()
    return render_template_string(STYLE+'''<div class="wrap"><a href="/">← Dashboard</a><h1>{{guild.name}}</h1><div class="card"><h2>Admin roles</h2><p class="muted">Members with any selected role can use admin bot commands in this server.</p><form method="post" action="/guild/{{guild.id}}/roles"><select name="role_id">{% for r in roles %}<option value="{{r.id}}">{{r.name}}</option>{% endfor %}</select> <button name="action" value="add">Add role</button> <button name="action" value="remove" class="danger">Remove role</button></form>{% for r in roles %}{% if r.id|int in configured %}<div class="role"><span>@{{r.name}} <span class="muted">({{r.id}})</span></span><span>✅ Admin</span></div>{% endif %}{% endfor %}</div></div>''',guild=guild,roles=roles,configured=configured)

@app.post("/guild/<int:guild_id>/roles")
def guild_roles(guild_id):
    r=require_login()
    if r: return r
    guild=next((g for g in guilds_for_user() if int(g["id"])==guild_id),None)
    if not guild or not can_manage_guild(guild): abort(403)
    role_id=int(request.form["role_id"]); action=request.form["action"]
    con=db()
    if action=="add":
        con.execute("INSERT OR IGNORE INTO admin_roles(guild_id,role_id,created_at,created_by) VALUES(?,?,datetime('now'),?)",(guild_id,role_id,int(current_user()["id"])))
    elif action=="remove":
        con.execute("DELETE FROM admin_roles WHERE guild_id=? AND role_id=?",(guild_id,role_id))
    con.commit(); con.close(); return redirect(f"/guild/{guild_id}")

if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=int(os.getenv("DASHBOARD_PORT","8080")))
