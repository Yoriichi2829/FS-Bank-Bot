# Discord Bank Bot

A persistent virtual-bank Discord bot built with Python, `discord.py`, SQLite, and Argon2 password hashing.

## Features

- `/register` account creation through a private Discord modal
- `/login` through a private modal
- Passwords are stored as Argon2 hashes, never plaintext
- Each bank account is permanently linked to the Discord user ID that created it
- Session timeout and login lockout/rate limiting
- `/balance`
- `/deposit` request + administrator approval
- `/withdraw` request + administrator approval
- `/transfer`
- `/transactions`
- Admin-only `/admin_pending`, `/admin_approve`, `/admin_deny`, `/admin_add_funds`, `/admin_remove_funds`, `/admin_credit`, `/admin_debit`, `/admin_user`, `/admin_list`
- SQLite persistence
- Atomic balance updates and transaction records
- Audit log for important account/admin actions

## Setup

1. Install Python 3.10+.
2. Create a Discord application and bot in the Discord Developer Portal.
3. Enable the bot and invite it with the `bot` and `applications.commands` scopes.
4. Install dependencies:

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# Linux/macOS:
source .venv/bin/activate

pip install -r requirements.txt
```

5. Copy `.env.example` to `.env`, then set:
   - `DISCORD_TOKEN` = your bot token
   - `BANK_ADMIN_IDS` = comma-separated Discord user IDs allowed to use admin commands

6. Export/load the environment variables. The example below uses a shell:

```bash
export DISCORD_TOKEN="YOUR_TOKEN"
export BANK_ADMIN_IDS="123456789012345678"
python bot.py
```

For Windows PowerShell:

```powershell
$env:DISCORD_TOKEN="YOUR_TOKEN"
$env:BANK_ADMIN_IDS="123456789012345678"
python bot.py
```

## How the money flow works

This is a **virtual bank**, not a real financial institution.

Users cannot create money by simply calling `/deposit`. Instead:

1. User calls `/deposit 1000`.
2. A pending request is created.
3. An administrator verifies the off-platform deposit and runs `/admin_approve REQUEST_ID`.
4. The balance is increased and an immutable transaction entry is recorded.

Withdrawals work similarly. This prevents the bot from becoming an unlimited-money command.

Administrators can also use `/admin_credit` and `/admin_debit` for controlled adjustments.

## Security model

- Passwords use Argon2id via `argon2-cffi`.
- Account lookup requires both the bank username and the Discord ID used to create the account.
- Login attempts are rate-limited and temporarily locked after repeated failures.
- Login responses are ephemeral.
- Balances are stored as integer cents to avoid floating-point money errors.
- Transfers use a SQLite write transaction (`BEGIN IMMEDIATE`) so both sides update atomically.
- Passwords and bot tokens are not written to the database.
- Never commit `.env` or `bank.db` to Git.

## Important limitation

Do not use this bot to hold, transfer, or represent real money, bank deposits, crypto, or other regulated financial assets without appropriate legal, security, compliance, and payment infrastructure. It is intended as a Discord virtual-currency/economy system.

## Recommended production hardening

For a public/high-value deployment, move the database to PostgreSQL, put secrets in a secret manager, use encrypted backups, add monitoring/alerting, restrict admin access further, and perform an independent security review.


## Admin fund generation/removal

Only Discord IDs listed in `BANK_ADMIN_IDS` can use `/admin_add_funds` and `/admin_remove_funds`. These commands directly adjust virtual balances, record transactions, and write audit-log entries. Removing funds cannot make a balance negative.

## Web dashboard and server admin roles

This version includes an optional web dashboard (`dashboard.py`). The dashboard lets an authorized Discord server owner/member with **Manage Server** permission:

- Log in with Discord OAuth2.
- See servers where they can manage the bot.
- Add or remove Discord roles that are allowed to use the bot's admin commands.
- Use **Add Bot to a Server** to generate the Discord OAuth2 installation link.

### Discord Developer Portal setup

Create an OAuth2 redirect URL matching `DISCORD_REDIRECT_URI`, for example:

`https://your-domain.example.com/callback`

Set these environment variables:

- `DISCORD_CLIENT_ID`
- `DISCORD_CLIENT_SECRET`
- `DISCORD_REDIRECT_URI`
- `DASHBOARD_URL`
- `DASHBOARD_SECRET`
- `DISCORD_TOKEN`

Run the bot and dashboard separately:

```bash
python bot.py
python dashboard.py
```

The dashboard defaults to port `8080` and must be served behind HTTPS in production. Never expose `DISCORD_CLIENT_SECRET`, `DISCORD_TOKEN`, or `DASHBOARD_SECRET` in client-side code.

### Admin authorization model

There are two kinds of administrators:

1. **Global admins** — Discord user IDs in `BANK_ADMIN_IDS`. These work across servers.
2. **Server admin roles** — roles configured in the dashboard for a specific server. Members with those roles can use admin commands in that server.

The bot still identifies bank accounts by immutable Discord user ID, not by mutable Discord username.

### Adding the bot

Open `/invite` on the dashboard. If `BOT_INVITE_URL` is empty, the dashboard generates the standard Discord installation URL using the application's client ID. Select the server and authorize the requested bot permissions.

For a public deployment, use a real HTTPS domain and a production WSGI server/reverse proxy rather than Flask's development server.
